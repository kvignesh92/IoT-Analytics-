# Install and import TSA package
install.packages("TSA")
library(TSA)

# read the data
raw = myts
# compute the Fourier Transform
p = periodogram(raw$data2.CloudCover)


dd = data.frame(freq=p$freq, spec=p$spec)
order = dd[order(-dd$spec),]
top2 = head(order, 2)

# display the 2 highest "power" frequencies
top2

# convert frequency to time periods
time = 1/top2$f
time








