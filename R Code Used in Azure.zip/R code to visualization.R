#install.packages("forecast")
#install.packages("xts")
#install.packages("reshape")
library(forecast)
library(xts)
library(reshape)

myts<-data.frame(data2$timestamp,data2$PrecipitationIn)
ZOO <- zoo(myts$data2.PrecipitationIn, order.by=myts$data2.timestamp)

#detect the trend
trend_wea = ma(ZOO, order = 366, centre = T)
plot(as.ts(ZOO))
lines(trend_wea)
plot(as.ts(trend_wea))

#detrend the time series
detrend_wea = ZOO - trend_wea
plot(as.ts(detrend_wea))

#average seasonality
m_wea = t(matrix(data = detrend_wea, nrow = 365))
seasonal_wea = colMeans(m_wea, na.rm = T)
plot(as.ts(rep(seasonal_wea,9)))

#random noise left
random_wea = ZOO - trend_wea - seasonal_wea
plot(as.ts(random_wea))

#reconstruct the original signal
recomposed_wea = trend_wea+seasonal_wea+random_wea
plot(as.ts(recomposed_wea))

#DECOMPOSE Time series decomposition in R
ts_wea = ts(ZOO, frequency = 365)
decompose_wea = decompose(ts_wea, "additive")

plot(as.ts(decompose_wea$seasonal))
plot(as.ts(decompose_wea$trend))
plot(as.ts(decompose_wea$random))
plot(decompose_wea)
########################################################################

#detect the trend
trend_weat = ma(ZOO2, order = 366, centre = T)
plot(as.ts(ZOO2))
lines(trend_wea)
plot(as.ts(trend_wea))


#detrend the time series
detrend_wea = ZOO - trend_wea
plot(as.ts(detrend_wea))

#average seasonality
m_wea = t(matrix(data = detrend_wea, nrow = 365))
seasonal_wea = colMeans(m_wea, na.rm = T)
plot(as.ts(rep(seasonal_wea,9)))

#random noise left
random_wea = ZOO - trend_wea - seasonal_wea
plot(as.ts(random_wea))

#reconstruct the original signal
recomposed_wea = trend_wea+seasonal_wea+random_wea
plot(as.ts(recomposed_wea))

#DECOMPOSE Time series decomposition in R
ts_wea = ts(ZOO, frequency = 365)
decompose_wea = decompose(ts_wea, "additive")

plot(as.ts(decompose_wea$seasonal))
plot(as.ts(decompose_wea$trend))
plot(as.ts(decompose_wea$random))
plot(decompose_wea)









